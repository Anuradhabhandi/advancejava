package com.jsp.springbootdemo2.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import com.jsp.springbootdemo2.dto.Student;
import com.jsp.springbootdemo2.repo.StudentRepo;

@Repository
public class StudentCurd {
	
	@Autowired
	private StudentRepo repo;
	
	public Student saveStudent(Student stu)
	{
		return repo.save(stu);
	}

	public Student updateStudent(@RequestParam Student  stu)
	{
		Optional<Student> op = repo.findById(stu.getId());
		if(op.isPresent())
		{
			Student db=op.get();
			db.setAddress(stu.getAddress());
			return repo.save(stu);
		}
		return null;
	}
}
