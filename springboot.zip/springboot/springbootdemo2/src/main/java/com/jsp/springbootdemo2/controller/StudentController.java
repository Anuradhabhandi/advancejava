package com.jsp.springbootdemo2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.springbootdemo2.dao.StudentCurd;
import com.jsp.springbootdemo2.dto.Student;

@RestController
public class StudentController {
	
	@Autowired
	private StudentCurd curd;
	
	@PostMapping("/save")
	public Student saveStudent(@RequestBody Student stu)
	{
		return curd.saveStudent(stu);
		
	}
	
	@GetMapping("/update")
	public Student updateStudent(Student stu)
	{
		return curd.updateStudent(stu);
	}
	
	

}
