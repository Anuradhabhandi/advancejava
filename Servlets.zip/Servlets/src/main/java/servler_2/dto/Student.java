package servler_2.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


import lombok.Data;

@Data
@Entity
public class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String fname;
	private String lname;
//	to make a column as unique
	@Column(unique = true)
	private String email;
	private String pswd;
	private long  phn;
	private String address;
	public Student(String fname, String lname, String email, String pswd, long phn, String add) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.email = email;
		this.pswd = pswd;
		this.phn = phn;
		this.address = add;
	}
	public Student() {
		super();
	}
	
	
	
	

}
