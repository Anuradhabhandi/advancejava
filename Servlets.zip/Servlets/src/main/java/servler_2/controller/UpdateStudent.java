package servler_2.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import servler_2.dao.StudentCrud;
import servler_2.dto.Student;

@WebServlet("/update")
public class UpdateStudent extends HttpServlet{
  @Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	int id=Integer.parseInt(req.getParameter("id"));
	StudentCrud crud=new StudentCrud();
	Student db=crud.fetchId(id);
	if(db!=null) {
		req.setAttribute("student",db);
		RequestDispatcher dis=req.getRequestDispatcher("update.jsp");
		dis.forward(req, resp);
	}
	else {
		req.setAttribute("msg", "email is wrong");
		RequestDispatcher dis=req.getRequestDispatcher("login.jsp");
		dis.forward(req, resp);
	}
		
}
  }
