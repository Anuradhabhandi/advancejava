package servler_2.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import servler_2.dao.StudentCrud;
import servler_2.dto.Student;

@WebServlet("/login")
public class StudentLogin extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	  String mail= req.getParameter("email");
	   String pwd=req.getParameter("pass");
	   
//	   System.out.println(mail+pwd);
	   StudentCrud crud=new StudentCrud();
	   try {	   
	   
		 Student db=crud.fetchEmail(mail);
		 
		if(db.getPswd().equals(pwd)) {
			
//			Student rmv = crud.delete(db.getId());
//			req.setAttribute("delete", rmv);
//			RequestDispatcher dis = req.getRequestDispatcher("printall.jsp");
//			dis.include(req, resp);
			
			
//			to fetch list of student details
			List<Student> list=crud.fetchAll();
			req.setAttribute("list", list);
			RequestDispatcher dis = req.getRequestDispatcher("printall.jsp");
			 dis.forward(req, resp);
			  
//			  to fetch single student data
//			req.setAttribute("student", db);
//			RequestDispatcher dis = req.getRequestDispatcher("print.jsp");
//			dis.forward(req, resp);
			
		}
		else {
			   req.setAttribute("msg", "Password Wrong");
			    RequestDispatcher dis = req.getRequestDispatcher("login.jsp");
			    dis.include(req, resp);
		}
	} 
	   catch (Exception e) {
		req.setAttribute("msg","E-mail wrong");
		RequestDispatcher dis = req.getRequestDispatcher("login.jsp");
		dis.include(req, resp);
	}
	}

}
