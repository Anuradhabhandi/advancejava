package servler_2.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import servler_2.dao.StudentCrud;
import servler_2.dto.Student;

@WebServlet("/updateStu")
public class EditStudent extends HttpServlet{
      @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	
    	  System.out.println("hi");
    	  
    	  String id=req.getParameter("id");
    	  String fname = req.getParameter("fname");
		   String lname = req.getParameter("lname");
		   String email = req.getParameter("mail");
		   String pswd = req.getParameter("pwd");
		   String phn = req.getParameter("phn");
		   String add = req.getParameter("add");
		    
		   Student student=new Student(fname,lname,email,pswd,Long.parseLong(phn),add);
//		   student.setId(Integer.parseInt(id));
		 
		   StudentCrud crud=new StudentCrud();
		   Student db =crud.updateStudent(student);
		   if(db!=null) {
			   List<Student> list=crud.fetchAll();
				req.setAttribute("list", list);
				RequestDispatcher dis = req.getRequestDispatcher("printall.jsp");
				 dis.forward(req, resp);
		   }
    }
}
