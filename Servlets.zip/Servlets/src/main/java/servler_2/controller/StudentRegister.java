package servler_2.controller;

//we are executing programs by using deployment descriptor

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import servler_2.dao.StudentCrud;
import servler_2.dto.Student;
@WebServlet("/register")
public class StudentRegister extends HttpServlet {
	 @Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		   String fname = req.getParameter("fname");
		   String lname = req.getParameter("lname");
		   String email = req.getParameter("mail");
		   String pswd = req.getParameter("pwd");
		   String phn = req.getParameter("phn");
		   String add = req.getParameter("add");
		   
		   
		   StudentCrud sc=new StudentCrud();
		   Student stu = new Student(fname, lname, email, pswd, Long.parseLong(phn), add);
		   
		   PrintWriter writer = resp.getWriter();
		   try {
			sc.saveStudent(stu);
//			writer.print(fname+" Registration done!");
			RequestDispatcher dispatch = req.getRequestDispatcher("login.html");
			dispatch.forward(req, resp);
			
		} catch (Exception e) {
//			writer.print(fname+" not completed");
			
           RequestDispatcher dis = req.getRequestDispatcher("registration.html");
           dis.include(req, resp);
		}
		  
	 }
}
