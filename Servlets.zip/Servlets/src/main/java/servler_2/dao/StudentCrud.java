package servler_2.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import servler_2.dto.Student;

public class StudentCrud {
	
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("vani");
	EntityManager em = emf.createEntityManager();
	EntityTransaction et = em.getTransaction();
	
	
//	method for saving the data of Students
	public Student saveStudent(Student student)throws Exception {
		et.begin();
		em.persist(student);
		et.commit();
		return student;
		
	}
	
//	method for fetching the email from the student
	public Student fetchEmail(String email) throws Exception {
		Query query = em.createQuery("select a from Student a where a.email=?1");
		 query.setParameter(1, email);
		 
		 return (Student) query.getSingleResult();
	}
	
//	method for fetching all the data
	public List<Student> fetchAll() {
		   Query student = em.createQuery("select a from Student a");
		   return   student.getResultList();
	}
		
	
//	method for deletion of data based on email
	public Student delete(int id) {
		
		Student db = em.find(Student.class, id);
		if(db!=null) {
			et.begin();
			em.remove(db);
			et.commit();
		}
		return db;
	}
	
//	method to fetch the id
	public Student fetchId(int id) {
		Student db = em.find(Student.class, id);
		if(db!=null)
			return db;
		else
			return null;
		
	}
	
	public Student updateStudent(Student student) {
		 Student db=em.find(Student.class, student.getId());
		 if(db!=null) {
			 et.begin();
			 em.merge(student);
			 et.commit();
			 return student;
		 }
		 else
			 
		return null;
		
	}

}
