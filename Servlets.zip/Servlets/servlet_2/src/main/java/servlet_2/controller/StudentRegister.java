package servlet_2.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import servlet_2.dao.StudentCurd;

@WebServlet("/register")
public class StudentRegister extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name=req.getParameter("name");
		String phone=req.getParameter("phone");
		String email=req.getParameter("email");
		String password=req.getParameter("password");
		String address=req.getParameter("address");
		String fathername=req.getParameter("fathername");
		String mothername=req.getParameter("mothername");
		System.out.println(name+" "+phone+" "+email+" "+password+" "+address+" "+fathername+" "+mothername+" ");
		
		
		StudentCurd curd=new StudentCurd();
		
	}
	

}
