package servlet_1;

import java.io.IOException;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class Addition extends GenericServlet {

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		String value1=req.getParameter("value1");
		int a=Integer.parseInt(value1);
		int b=Integer.parseInt(req.getParameter("value2"));
		System.out.println(a+" + "+b+" = "+(a+b));
		
	}

}
