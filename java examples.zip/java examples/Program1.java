import java.lang.*;
public class Program1
{
public static void main(String args[])
{
String s1,s2,compare;
System.out.println("enter s1 name");
s1 name=toString();
System.out.println("enter s2 name");
s2 name=toString();
if(s1.equals(s2))
{
System.out.println("two string are equal");
}
else
{
System.out.println("two strings are not equal");
}
}
}