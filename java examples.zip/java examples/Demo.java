import java.lang.*;
class Perimeter
{
int length;
int breadth;
Perimeter(int x,int y)
{
length=x;
breadth=y;
}
void cal_Perimeter()
{
int Peri;
Peri=2*(length+breadth);
System.out.println("the perimeter of a recatngle is:"+Peri);
}
}
class Demo
{
public static void main(String args[])
{
Perimeter p1=new Perimeter(5,10);
p1.cal_Perimeter();
}
}
