class ComdLine
{
public static void main(String[] args)
{
int count,i=0;
count=args.length;
System.out.println("number of arguments="+count);
for(i=0;i<count;i++)
{
System.out.println("  java  is   "  +  args[i]);
}
}
}