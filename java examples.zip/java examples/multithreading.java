/* runnable interface*/
class Multithreading implements Runnable
{
public void run()
{
System.out.println("my thread is in running state");
}
public static void main(String args[])
{
Multithreading obj=new Multithreading();
Thread tobj=new Thread(obj);
tobj.start();
}
}