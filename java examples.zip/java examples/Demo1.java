class Demo1
{
public static void main(String args[])
{
int var=15;
var++;
System.out.println("var++="+var);
++var;
System.out.println("++var="+var);
}
}