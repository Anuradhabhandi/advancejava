import java.applet.Applet;
import java.awt.*;
public class GraphicsDemo extends Applet
{
public void paint(Graphics g)
{
g.setColor(Color.red);
g.drawString("welcome",50,50);
g.drawLine(20,30,20,200);
g.drawRect(70,100,30,30);
g.fillRect(170,100,30,30);
g.drawOval(70,200,30,30);
g.setColor(Color.pink);
g.fillOval(170,120,30,30);
g.drawArc(90,125,30,30,270);
g.fillArc(270,150,30,0,180);
}
}
/*<applet code=GraphicsDemo width=100 height=200>
</applet>
*/