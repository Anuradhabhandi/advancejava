class Linear 
{
static int linearSearch(int a[],int n ,int val)
{
for(int i=0;i<n;i++)
{
if (a[i]==val)
return i+1;
}
return -1;
}
public static void main(String args[])
{
int a[]={70,40,30,11,57};
int val=11;
int n=a.length;
int res =linearSearch (a,n,val);
System.out.println();
System.out.println("the elements of the array are");
for(int i=0;i<n;i++)
System.out.println(" "+a[i]);
System.out.println();
System.out.println("element to be searched is  "+ val);
if(res==-1)
System.out.println("element is not present in the array");
else
System.out.println("element is present at" +  res + "position of array");
}
}
