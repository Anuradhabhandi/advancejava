import java.awt.*;
import java .applet.Applet;
public class LabelDemo extends Applet
{
public void init()
{
setBackground(Color.white);
setForeground (Color.yellow);
Label l1=new Label("VIM");
Label l2=new Label("COLLEGE");
add(l1);
add(l2);
}
public void paint(Graphics g)
{
g.drawString("LabelDemo" ,50,50);
}
}
/*<applet code=LabelDemo width=400 height=100>
</applet>
*/