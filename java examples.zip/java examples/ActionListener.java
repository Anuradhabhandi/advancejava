import java.awt.event.*;
import java.applet.Applet;
public class Implement  Extends  Applet
{
Label L1,L2;
TextField T1,T2;
Button B1,B2;
public void init()
{
L1=new label("enter number");
L2=new label("result");
T1=new TextField(20);
T2=new TextField(20);
T2.setEditable(false);
B1.button("square");
B2.button("cube");
add(L1);
add(T1);
add(L2);
add(T2);
B1.addActionListener(this);
B2.addActionListener(this);
}
public void actionPerformance(actionEvent ae)
{
int n=Integer.parseInt(T1.getText());
int r=0;
if(ae.getSource()==B1)
r=n*n;
else
if(ae.getSource()==B2)
r=n*n*n;
String s=string.valueOf(r);
T2.setText(s);
}
}