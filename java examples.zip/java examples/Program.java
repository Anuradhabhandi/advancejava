import java.lang.*;
public class Program
{
public static void main(String args[])
{
String s1,s2;
System.out.println("enter s1 name");
System.out.println("anvita");
System.out.println("enter s2 name");
System.out.println("anu");
System.out.println("comapring"+s1+"and"+s2+":"+s1.equals (s2));
}
} 