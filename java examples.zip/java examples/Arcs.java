import java.awt.*;
import java.applet.*;
/*
<applet code=arc width=200 height=100>
</applet>
*/
public class Arc extends Applet
{
public void init()
{
setBackground(Color.pink);
setForeground(Color.blue);
}
public void paint(Graphics g)
{
g.drawArc(10,50,60,30,50,40);
g.fillArc(110,50,70,40,100,90);
g.drawArc(50,60,30,70,60,90);
g.fillArc(100,60,90,50,60,90);
}
}