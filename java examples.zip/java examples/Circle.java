import java .util.Scanner;
public  class Circle
{
public static void main(String args[])
{

Scanner sc=new Scanner(System.in);
System.out.println("enter the radius :");
double radius=sc.nextDouble();
double Area=Math. PI*(radius*radius);
System.out.println("the area of circle="+Area);
double Circumference=Math .PI*2*radius;
System.out.println("the circumference of the circle is="+Circumference);
}
}

