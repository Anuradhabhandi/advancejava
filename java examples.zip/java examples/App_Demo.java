import java.applet.Applet;
import java.awt.*;
public  class App_Graph extends Applet
{
public void paint(Graphics g)
{
g.drawString(20,20,100,200);
g.setColor(color,red);
}
}
/*
<Applet code=App_Graph width=400 height=400>
</Applet>
*/