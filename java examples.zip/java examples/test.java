import java.applet.Applet;
import java.awt.*;
public test extends Applet
{
String s;
public void init()
{
S="-first-";
}
public void start()
{
S=S+"-second-";
}
public void paint(Graphics g)
{
S=S+"-third-";
g.drawString(Str,20,20);
}
}
/*
<applet code=test width=35 height=45>
</applet>
*/