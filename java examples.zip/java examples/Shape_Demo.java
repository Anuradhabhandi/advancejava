import java.applet.Applet;
import java .awt.*;
public class Shape_Demo extends Applet
{
public void paint(Graphics g)
{
g.drawOval(40,40,120,150);
g.drawOval(100,80,50,50);
g.drawRect(100,200,200,100);
g.drawLine(20,100,400,100);
}
}
/*<applet code="Shape_Demo" height=200 width=100>
</applet>
*/