/*interafce demo*/
interface Figure
{
final double pi=3.142;
void compute();
}
class Circle implements Figure
{
double r,area;
Circle(double x)
{
r=x;
}
public void compute()
{
area=pi*r*r;
System.out.println("area of circle="+area);
}
}
class InterfaceDemo
{
public static void main(String args[])
{
Circle c1=new Circle(2.6);
c1.compute();
}
}
