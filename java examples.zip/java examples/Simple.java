import java.util.Scanner;
class Simple
{
public static void main(String args[])
{
float p,t,r,si;
Scanner  scan=new Scanner(System.in);
System.out.println("enter the principal");
p=scan .nextFloat();
System.out.println("enter the rate of interest");
r=scan. nextFloat();
System.out.println("enter the time period");
t=scan. nextFloat();
scan.close();
si=(p*t*r)/100;
System.out.println("simple interest is:"+si);
}
}


