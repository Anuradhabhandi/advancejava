import java.awt.*;
import java.applet.*;
public class Display extends Applet
{
Image img;
public void init()
{
img=getImage(getDocumentBase(),"img1.jpg");
}
}
/*<applet code=Display width=100 height=150>
</applet>
*/