import java.awt.*;
import java.applet.*;
/*
<applet code=HourGlass width=230 height=200>
</applet>
*/
public class HourGlass extends Applet
{
public void init()
{
setBackground(Color.pink);
setForeground(Color.green);
}
public void paint(Graphics  g)
{
int xpoints[]={30,200,40,60,90};
int ypoints[]={100,60,90,50,110};
int num=5;
g.drawPolygon(xpoints ,ypoints,num);
}
}
