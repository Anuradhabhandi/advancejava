import java.awt.*;
import java.applet.Applet;
public class First extends Applet
{
public void paint(Graphics g)
{
g.drawString("welcome",250,150);
}
}
/* <applet code=First width=100 height=200>
</applet>
*/
