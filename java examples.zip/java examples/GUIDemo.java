import java.awt.*;
import java.applet.Applet;
public class GUIDemo extends Applet
{
Label L1,L2,L3,L4;
TextField T1,T2,T4;
TextArea Ta;
Button B1;
Choice Ch;
public void init()
{
L1=new Label(" first name:");
L2=new Label("last name:");
L3=new Label("address:");
L4=new Label("gender");
T1=new TextField(20);
T2=new TextField(20);
Ta=new TextArea(20,10);
T4=new TextField(20);
B1=new Button("submit");
Ch=new Choice();
Ch.addItem("male");
Ch. addItem("female");
add(L1);
add(T1);
add(L2);
add(T2);
add(L3);
add(Ta);
add(T4);
add(Ch);
add(B1);
}
}
/*
<Applet code=GUIDemo width=100 height=100>
</Applet>
*/

