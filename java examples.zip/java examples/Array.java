class Array
{
public static void main(String args[])
{
int a[]={10,20,30,40,50};
int Sum=0;
for(int i=0;i<a.length;i++)
{
Sum=Sum+a[i];
}
System.out.println("sum of array="+Sum);
}
}