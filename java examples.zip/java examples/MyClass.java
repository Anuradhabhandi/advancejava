import java.applet.Applet;
import java .awt.event.*;
import java.awt.*;
public class  MyClass   implements    ActionListener
{
Label L1,L2;
TextField T1,T2;
Button B1,B2;
public void init()
{
L1=new Label("enter number");
L2=new Label("result");
 T1=new TextField(20);
T2=new TextField(20);
B1=new Button("square");
B2=new Button("cube");
add(L1);
add(T1);
add(L2);
add(T2);
B1.addActionListener(this);
B2.addActionListener(this);
}
public void actionPerformance(ActionEvent ae)
{
int n=Integer.parseInt(T1.getText());
int r=0;
if(ae.getSource()==B1)
r=n*n;
else
if(ae.getSource()==B2)
r=n*n*n;
String s=String.valueOf(r);
T2.setText(s);
}
}

/*
<Applet code=MyClass width=100 height=150>
</Applet>
*/
