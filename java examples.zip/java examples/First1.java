
import *
Class Arithmetic
{
public static void main(String args[])
{
System.out.println("program start");
int a;
int b;
int res;
a=30;
b=40;
res=a+b;
System.out.println("value of a");
System.out.println(a);
System.out.println("value of b");
System.out.println(b);
System.out.println("addition of a and b");
System.out.println(res);
System.out.println("program end!");
}
}