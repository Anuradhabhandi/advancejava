import java.lang.*;
public class parameter
{
int square;
int cube;
parameter(int a,int b)
{
square=a;
cube=b;
}
void call_parameter()
{
int para;
square=a*a;
cube=b*b*b;
System.out.println("square of a given number:"+square);
System.out.println("cub of a given number:"+cube);
}
class Parameter1
{
public static void main(String args[])
{
parameter p1=new parameter(3,5);
p1.parameter();
}
}
} 