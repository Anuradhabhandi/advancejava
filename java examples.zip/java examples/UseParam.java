import java.applet.Applet;
import java.awt.Graphics;
public class UseParam extends Applet
{
public void Paint(Graphics g)
{
String str=getParameter("msg");
g.drawString(str,50,50);
g.drawString(Picture,30,30,this);
}
}
/*<applet code=UseParam width=100 height=150>
<param name="msg" value="welcome to applet">
</applet>
*/