import java.applet.*;
import java.awt.*;
/* <applet code=Polygon width=100 height=200>
</applet>
*/
public  class Polygon extends Applet
{
public void init()
{
setBackground(Color.red);
setForeground(Color.pink);
}
public void paint(Graphics g)
{
int[]  xpoints[]={{50,25,35,75,75},{100,100,150,100,150,150,125,100,150},{100,100,150,100,150,150,125,100,150}};
int[] ypoints[]={{110,135,185,185,135},{85,35,35,85,85,35,10,35,85},{185,135,135,185,185,135,110,135,185}};
int npoints[]={5,9,9,9};
g.drawPolygon(xpoints[0],ypoints[0],npoints[0]);
g.fillPolygon(xpoints[1],ypoints[1],npoints[1]);
g.drawPolygon(xpoints[2],ypoints[2],npoints[2]);
g.fillPolygon(xpoints[3],ypoints[3],npoints[3]);
}
}


