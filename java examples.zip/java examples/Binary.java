class Binary
{
static int binarySearch(int a[],int start,int stop,int val)
{
int mid;
if(stop>=start)
{
mid=(start+stop)/2;
if(a[mid]==val)
{
return mid+1;
}
else if(a[mid]<val)
{
return binarySearch(a,mid+1,stop,val);
}
else
{
return binarySearch(a,start,mid-1,val);
}
}
return -1;
}
public static void main(String args[])
{
int a[]={10,12,24,29,39};
int val=29;
int n=a.length;
int res=binarySearch(a,0,n-1,val);
System.out.println("the element of the array are:");
for(int i=0;i<n;i++)
{
System.out.println(a[i]+" ");
}
System.out.println();
System.out.println("element to be searched is:"+val);
if (res==-1)
System.out.println("element is not present in the array");
else
System.out.println("element is present at "+ res + "position of array");
}
} 