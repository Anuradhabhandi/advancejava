import java.awt.*;
import java .applet.Applet;
public class CheckBoxDemo extends Applet
{
public void init()
{
Checkbox c1=new Checkbox("cricket");
Checkbox c2=new Checkbox("tennis");
add(c1);
add(c2);
}
public void paint(Graphics g)
{
g.drawString ("CheckBoxDemo",100,100);
}
}
/*<applet code=CheckBoxDemo width=100 height=200>
</applet>
*/