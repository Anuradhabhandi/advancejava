class Parent
{
void display()
{
System.out.println("parent");
}
}
class Child extends Parent
{
void display()
{
System.out.println("child");
}
}
class OverRide
{
public static void main(String args[])
{
Child obj=new Child();
obj.display();
}
}
