import java .awt.*;
import java.applet.*;
/*
<applet code=Ovals width=200 height=1077  0>
</applet>
*/
public class Ovals extends Applet
{
public void init()
{
setBackground(Color.red);
setForeground(Color.blue);
}
public void paint(Graphics  g)
{
g.drawOval(10,10,50,50);
g.fillOval(10,20,60,50);
g.drawOval(110,50,10,50);
g.fillOval(50,90,60,40);
}
}