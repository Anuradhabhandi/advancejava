import java.awt.*;
import java.applet.*;
/*
<applet code="Rect1" width=100 height=100>
</applet>
*/
public class Rect1 extends Applet
{
public void init()
{
setBackground(Color.black);
}
public void paint(Graphics g)
{
g.setColor(Color.gray);
g.drawRect(25,10,50,75);
g.drawRect(25,110,50,75);
g.fillRect(100,10,50,75);
g.fillRect(100,110,50,75 );
}
} 