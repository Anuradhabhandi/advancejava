class Box
{
double width;
double height;
double depth;
Box()
{
width=4.0;
height=5.0;
depth=2.0;
}
Box(double x,double y,double z)
{
width=x;
height=y;
depth=z;
}

 class Double
{
public static void main(String args[])
{
double vol;
vol=width*height*depth;
return(vol);
}
}
}