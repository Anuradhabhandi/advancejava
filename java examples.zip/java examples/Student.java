class Student
{
int regno;
String name;
Student()
{
regno=Integer.parseInt("101");
name="anvita";
}
public static void main(String args[])
{
Student s1=new Student();
System.out.println(s1.regno);
System.out.println(s1.name);
}
}