/* factorial of a given number */
class For
{
public static void main(String args[])
{
int f=1;
int n=4;
for(int i=1;i<n;i++)
{
f=f*i;
}
System.out.println("fact="+f);
}
}