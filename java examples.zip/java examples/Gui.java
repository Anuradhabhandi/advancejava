import java.awt.*;
import java.applet.Applet;
public class Gui extends Applet
{
Label L1,L2,L3,L4;
TextField T1,T2,T4;
TextArea Ta;
Button B1;
Choice ch; 
public void init()
{
L1=new Label("first number");
L2=new Label("second number");
L3=new Label("address");
L4=new Label("gender");
T1=new  TextField(20);
T2=new TextField(20);
Ta=new TextArea(10,20);
T4=new TextField(20);
B1=new Button("submit");
ch=new Choice();
ch.addItem("male");
ch.addItem("female");
add(L1);
add(T1);
add(L2);
add(T2);
add(L3);
add(Ta);
add(L4);
add(ch);
add(B1);
}
}
/* 
<applet code=Gui width=100 height=120>
</applet>
*/ 