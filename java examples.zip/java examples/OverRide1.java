class parent
{
void display()
{
System.out.println("parent");
}
}
class child extends parent
{
void display();
{
System.out.println("child");
}
}
class OverRide1
{
public static void main(String args[])
{
Child obj=new Child();
obj.display();
}
}