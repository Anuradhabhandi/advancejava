class Room
{
float l,b;
void getdata(float x ,float y)
{
l=x;
b=y;
}
}
class FactArea
{
public static void main(String args[])
{
float area;
Room r1=new Room();
r1.getdata(10,15);
area=r1.l*r1.b;
System.out.println("area="+area);
}
}