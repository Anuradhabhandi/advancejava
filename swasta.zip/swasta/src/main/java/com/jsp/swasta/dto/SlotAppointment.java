package com.jsp.swasta.dto;

public class SlotAppointment {

}
