package com.jsp.swasta.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import lombok.Data;

@Entity
@Data
public class User {
	
	private int id;
	private String firstName;
	private String lastName;
	private int age;
	@Column(unique=true)
	private String email;
	private long phone;
	private String bloodGroup;
	private String avalibility;
	private String gender;
	private String password;
	
	@OneToOne
	@JoinColumn
	private Address address;
	
	
	

}
