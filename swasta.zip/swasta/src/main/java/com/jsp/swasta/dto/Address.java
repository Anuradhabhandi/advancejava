package com.jsp.swasta.dto;

import javax.persistence.OneToOne;

public class Address {

	private int id;
	private String door_No;
	private String street;
	private String city;
	private String state;
	private int pincode;
	
	@OneToOne(mappedBy = "address")
	private User user;
}
