package com.jsp.swasta.dto;

public class DateAppointment {
	


}
