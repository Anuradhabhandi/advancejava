package com.jsp.swasta.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.jsp.swasta.dao.UserDao;
import com.jsp.swasta.dto.User;
import com.jsp.swasta.util.ResponseStructure;

@Service
public class UserService {
	
	@Autowired
	private UserDao dao;
	
	
	public ResponseEntity<ResponseStructure<User>> saveUser(User user)
	{
		ResponseStructure<User>structure=new ResponseStructure<User>();
		structure.setData(dao.saveUser(user));
		structure.setMessage("insertion is succesfully");
		structure.setStatus(HttpStatus.CREATED.value());
		
	
		
		return new ResponseEntity<ResponseStructure<User>>(structure,HttpStatus.FOUND);
	}

}
