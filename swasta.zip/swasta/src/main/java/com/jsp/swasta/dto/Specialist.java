package com.jsp.swasta.dto;

import javax.persistence.OneToOne;

public class Specialist {
	private int id;
	private String email;
	private long phone;
	private String specialist;
	private int experience;
	private int age;
	private String gender;
	private long fees;
	
	@OneToOne
	private Address address;
	

}
