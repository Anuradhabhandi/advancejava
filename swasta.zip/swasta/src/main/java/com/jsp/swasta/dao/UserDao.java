package com.jsp.swasta.dao;

import com.jsp.swasta.dto.User;
import com.jsp.swasta.repo.UserRepo;

public class UserDao {
	
	private UserRepo repo;
	
	public User saveUser(User user)
	{
		return repo.save(user);
	}

}
