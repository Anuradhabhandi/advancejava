package com.jsp.swasta.dto;

import java.util.List;

import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

public class Hospital {
	
	private int id;
	private String name;
	private String website;
	private long phone;
	private String email;
	
	@ManyToOne
	private List<Specialist>specialist;
	
	@OneToOne
	private Address address;

}
