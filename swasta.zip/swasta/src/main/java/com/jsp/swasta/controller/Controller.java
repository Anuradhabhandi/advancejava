package com.jsp.swasta.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.swasta.dto.User;
import com.jsp.swasta.service.UserService;
import com.jsp.swasta.util.ResponseStructure;

@RestController
public class Controller {
	
	@Autowired
	private UserService service;
	
	@PostMapping("/saveuser")
	public ResponseEntity<ResponseStructure<User>> saveUser(@RequestBody User user)
	{
		return service.saveUser(user);
	}

}
