package com.jsp.swasta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwastaApplicationTests {

	@Test
	void contextLoads() {
	}

}
